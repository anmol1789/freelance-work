# Pandey Ji Content Studio — Website

A responsive, single-page website with a live slot-booking flow, built for **Pandey Ji Content Studio Pvt. Ltd.** (Shubham Pratyush).

## Files
- `index.html` — page structure & content
- `style.css` — all styling (cinematic black/red brand theme)
- `script.js` — calendar, slot grid, form, WhatsApp booking logic

## How booking works (no backend needed)
1. Visitor picks a date (next 21 days) and an open time slot (9 AM–8 PM, hourly).
2. They fill in their details and tap **Send Booking Request on WhatsApp**.
3. Their browser opens WhatsApp with a pre-filled message to **+91 92638 50271** containing their name, phone, service, location, date/time and notes.
4. That slot is marked **Requested** on their device (via browser storage) so they can't accidentally double-book it themselves.
5. Shubham confirms the booking by replying on WhatsApp or calling.

### Marking a slot as officially "Booked" for everyone
Because there's no server/database, slot status only syncs on the visitor's own device automatically. Once you've confirmed a booking (by call/WhatsApp), open `script.js` and add it to the `CONFIRMED_BOOKINGS` object near the top:

```js
const CONFIRMED_BOOKINGS = {
  "2026-08-05": ["10:00", "15:00"],   // Aug 5, 2026 — 10 AM and 3 PM booked
  "2026-08-06": ["09:00"],
};
```

Save the file and re-upload/redeploy — that slot will now show as **Booked** (greyed out) for every visitor. Do this every time you confirm a new shoot.

> **Want it fully automatic across every visitor in real time (no manual editing)?**
> That needs a small backend — e.g. a free Google Sheet + Apps Script, Firebase, or Airtable — so every booking writes to one shared calendar instantly. Happy to wire that up if you want to upgrade later.

## Editing content
- **Phone number:** change the `PHONE` constant at the top of `script.js`, and update the `tel:`/`wa.me` links and visible number in `index.html`.
- **Working hours/days:** change `WORK_START_HOUR` / `WORK_END_HOUR` in `script.js`.
- **Services / reel types:** edit the lists in the "Services" and "Specialities" sections of `index.html`, and the `REELS` array in `script.js`.
- **Instagram handle:** update the links in the Contact section and footer of `index.html`.

## Deploying
This is a static site — no build step, no server required. You can host it for free on any of these:
- **Netlify** or **Vercel** — drag-and-drop the folder, done in ~1 minute.
- **GitHub Pages** — push the 3 files to a repo and enable Pages.
- Any regular web hosting (just upload the files via FTP/cPanel).

Then point your domain (e.g. `pandeyjicontentstudio.com`) at it.

## Notes
- Fully responsive: tested down to small mobile widths.
- No tracking, no ads, no external dependencies besides Google Fonts (loaded via CDN link in `index.html`).
- All copy states the company as **legally registered under the Ministry of Corporate Affairs, Government of India**, without publishing the CIN/certificate number publicly (kept private for the business, as is standard).
